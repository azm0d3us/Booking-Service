package com.test.securewebapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SecureWebAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(SecureWebAppApplication.class, args);
	}

}
